package com.example.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class AttendanceSession(
    val id: Long, // timestamp
    val date: String, // DD-MM-YYYY
    val department: String,
    val subject: String,
    val timeSlot: String,
    val classType: String,
    val records: Map<String, Boolean> // USN -> presence (true = Present, false = Absent)
)

object AttendanceStorage {
    private const val FILE_NAME = "attendance_master.json"

    private fun getFile(context: Context): File {
        return File(context.filesDir, FILE_NAME)
    }

    suspend fun saveSession(context: Context, session: AttendanceSession): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = getFile(context)
            val sessions = loadAllSessions(context).toMutableList()
            
            // Add or overwrite if the exact same timestamp exists
            sessions.add(session)

            val jsonArray = JSONArray()
            for (s in sessions) {
                val sObj = JSONObject().apply {
                    put("id", s.id)
                    put("date", s.date)
                    put("department", s.department)
                    put("subject", s.subject)
                    put("time-slot", s.timeSlot)
                    put("class-type", s.classType)
                    
                    val recordsObj = JSONObject()
                    for ((usn, present) in s.records) {
                        recordsObj.put(usn, present)
                    }
                    put("records", recordsObj)
                }
                jsonArray.put(sObj)
            }

            file.writeText(jsonArray.toString(2))
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun loadAllSessions(context: Context): List<AttendanceSession> = withContext(Dispatchers.IO) {
        val file = getFile(context)
        if (!file.exists()) {
            return@withContext emptyList()
        }

        try {
            val content = file.readText()
            if (content.isBlank()) return@withContext emptyList()
            
            val jsonArray = JSONArray(content)
            val list = mutableListOf<AttendanceSession>()
            for (i in 0 until jsonArray.length()) {
                val sObj = jsonArray.getJSONObject(i)
                val id = sObj.getLong("id")
                val date = sObj.optString("date", "Unknown Date")
                val department = sObj.optString("department", "Unknown Dept")
                val subject = sObj.optString("subject", "Unknown Subject")
                val timeSlot = sObj.optString("time-slot", "Unknown Time")
                val classType = sObj.optString("class-type", "Theory")

                val recordsObj = sObj.optJSONObject("records")
                val records = mutableMapOf<String, Boolean>()
                if (recordsObj != null) {
                    val keys = recordsObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        records[key] = recordsObj.optBoolean(key, false)
                    }
                }

                list.add(
                    AttendanceSession(
                        id = id,
                        date = date,
                        department = department,
                        subject = subject,
                        timeSlot = timeSlot,
                        classType = classType,
                        records = records
                    )
                )
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    suspend fun deleteSession(context: Context, sessionId: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = getFile(context)
            val sessions = loadAllSessions(context).filter { it.id != sessionId }

            val jsonArray = JSONArray()
            for (s in sessions) {
                val sObj = JSONObject().apply {
                    put("id", s.id)
                    put("date", s.date)
                    put("department", s.department)
                    put("subject", s.subject)
                    put("time-slot", s.timeSlot)
                    put("class-type", s.classType)
                    
                    val recordsObj = JSONObject()
                    for ((usn, present) in s.records) {
                        recordsObj.put(usn, present)
                    }
                    put("records", recordsObj)
                }
                jsonArray.put(sObj)
            }

            file.writeText(jsonArray.toString(2))
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
