package com.example.data

data class Student(
    val usn: String,
    val name: String
)

object StudentRepository {
    val computerScienceStudents = listOf(
        Student("3NG23CS002", "ABHISHEK"),
        Student("3NG23CS003", "ABHISHEK GOUDA"),
        Student("3NG23CS004", "AISHWARYA H"),
        Student("3NG23CS005", "AMARESH"),
        Student("3NG23CS006", "ANUSHA G"),
        Student("3NG23CS007", "ASFIYA JALEES"),
        Student("3NG23CS009", "ASMA IMAMASAB"),
        Student("3NG23CS010", "B AKHILA"),
        Student("3NG23CS012", "BASAVARAJ"),
        Student("3NG23CS014", "BINDUSHREE S"),
        Student("3NG23CS015", "DARSHAN"),
        Student("3NG23CS017", "DEVIKA"),
        Student("3NG23CS020", "IRAMMA ANGADI"),
        Student("3NG23CS022", "K MAHESH KUMAR"),
        Student("3NG23CS024", "KARTHIK G V"),
        Student("3NG23CS025", "KAVITA ALLAPUR"),
        Student("3NG23CS026", "KOUSALYA B K"),
        Student("3NG23CS027", "KOUSHAL RATHOD"),
        Student("3NG23CS028", "LAXMI"),
        Student("3NG23CS029", "M AKASH"),
        Student("3NG23CS030", "M BHARGAVI"),
        Student("3NG23CS031", "MALLAMMA"),
        Student("3NG23CS032", "HANUMESHA"),
        Student("3NG23CS033", "NAGARAJ BENNUR"),
        Student("3NG23CS035", "NAVEENAGOUDA"),
        Student("3NG23CS036", "NETRAVATHI"),
        Student("3NG23CS037", "NIVEDITA"),
        Student("3NG23CS038", "P PRIYANKA"),
        Student("3NG23CS040", "PRAGATI HONGAL"),
        Student("3NG23CS041", "RAGHUNANDA B"),
        Student("3NG23CS042", "RAGI JAGANNATHAIAH"),
        Student("3NG23CS043", "RAHUL"),
        Student("3NG23CS044", "RAJUGOUDA"),
        Student("3NG23CS045", "RAKSHITHA DAROJI"),
        Student("3NG23CS046", "REVANASIDDAYYA"),
        Student("3NG23CS047", "RUKSANA BEGUM P"),
        Student("3NG23CS048", "S M LAVANYA"),
        Student("3NG23CS049", "SABA SULTANA"),
        Student("3NG23CS050", "SAMEENA"),
        Student("3NG23CS051", "SHARADA GALABI"),
        Student("3NG23CS052", "SINDHU"),
        Student("3NG23CS053", "SUNIL"),
        Student("3NG23CS054", "TEJASHWINI VAJRAD"),
        Student("3NG23CS055", "TUKARAMAPPA"),
        Student("3NG23CS056", "VINOD"),
        Student("3NG23CS057", "YUVARAJ B H"),
        Student("3NG23CS058", "RANJITHA K"),
        Student("3NG24CS400", "AISHWARYA LALGE"),
        Student("3NG24CS401", "H SHIVARAJA"),
        Student("3NG24CS402", "IQHRA FATHIMA"),
        Student("3NG24CS403", "KAMALA"),
        Student("3NG24CS404", "MD RAFEEQ"),
        Student("3NG24CS405", "MD SAFIUDDIN"),
        Student("3NG24CS406", "Y S YOGESH")
    )

    val electronicsStudents = listOf(
        Student("1CS21EC001", "Arjun Mehta"),
        Student("1CS21EC002", "Divya Shetty"),
        Student("1CS21EC003", "Manoj Kumar"),
        Student("1CS21EC004", "Nidhi Joshi"),
        Student("1CS21EC005", "Rahul Deshmukh"),
        Student("1CS21EC006", "Shwetha Shenoy"),
        Student("1CS21EC007", "Varun Kulkarni"),
        Student("1CS21EC008", "Harini S."),
        Student("1CS21EC009", "Pranav Prasad"),
        Student("1CS21EC010", "Amrita Pillai")
    )

    val civilStudents = listOf(
        Student("1CS21CV001", "Basavaraj M."),
        Student("1CS21CV002", "Chaitra Bhat"),
        Student("1CS21CV003", "Darshan Gowda"),
        Student("1CS21CV004", "Eshwar Prasad"),
        Student("1CS21CV005", "Geetha S."),
        Student("1CS21CV006", "Jagadish K."),
        Student("1CS21CV007", "Laxmi Patel"),
        Student("1CS21CV008", "Naveen Kumar"),
        Student("1CS21CV009", "Pooja Hegde"),
        Student("1CS21CV010", "Rajesh V.")
    )

    val mechanicalStudents = listOf(
        Student("1CS21ME001", "Akash Singh"),
        Student("1CS21ME002", "Bharat Rao"),
        Student("1CS21ME003", "Chetan Kumar"),
        Student("1CS21ME004", "Deepak G."),
        Student("1CS21ME005", "Girish Kumar"),
        Student("1CS21ME006", "Karthik Gowda"),
        Student("1CS21ME007", "Lokesh V."),
        Student("1CS21ME008", "Madhav Rao"),
        Student("1CS21ME009", "Nitin Shenoy"),
        Student("1CS21ME010", "Praveen Kumar")
    )

    val electricalStudents = listOf(
        Student("1CS21EE001", "Abhay Deshpande"),
        Student("1CS21EE002", "Bindu Madhavi"),
        Student("1CS21EE003", "Kiran Kumar"),
        Student("1CS21EE004", "Mahesh S."),
        Student("1CS21EE005", "Preeti Nayak"),
        Student("1CS21EE006", "Ramya Gowda"),
        Student("1CS21EE007", "Sachin Tendulkar"),
        Student("1CS21EE008", "Tejas Patil"),
        Student("1CS21EE009", "Vijay Kumar"),
        Student("1CS21EE010", "Yashwanth S.")
    )

    fun getStudentsForDepartment(department: String): List<Student> {
        return when (department) {
            "Computer Science & Engg" -> computerScienceStudents
            "Electronic & Communication Engg" -> electronicsStudents
            "Civil Engg" -> civilStudents
            "Mechanical Engg" -> mechanicalStudents
            "Electrical & Electronic Engg" -> electricalStudents
            else -> emptyList()
        }
    }
}
