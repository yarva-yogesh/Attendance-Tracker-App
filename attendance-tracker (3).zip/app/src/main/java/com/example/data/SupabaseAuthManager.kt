package com.example.data

import android.util.Log
import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SupabaseAuthManager {
    private const val TAG = "SupabaseAuthManager"
    private val client = OkHttpClient()

    private val supabaseUrl: String
        get() {
            val url = try { BuildConfig.SUPABASE_URL } catch (e: Throwable) { "" }
            return if (url.isBlank() || url.contains("YOUR_SUPABASE")) {
                "https://qxcirrrkwcvmrdlbkqvs.supabase.co"
            } else {
                url
            }
        }

    private val supabaseAnonKey: String
        get() {
            val key = try { BuildConfig.SUPABASE_ANON_KEY } catch (e: Throwable) { "" }
            return if (key.isBlank() || key.contains("YOUR_SUPABASE")) {
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF4Y2lycnJrd2N2bXJkbGJrcXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM5NDk2MTgsImV4cCI6MjA5OTUyNTYxOH0.iZKvN_ED_IFNBPI4_3rNh_dCtddYlfWrxpHlKAhsQVU"
            } else {
                key
            }
        }

    suspend fun signInWithEmail(email: String, password: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "$supabaseUrl/auth/v1/token?grant_type=password"
            val jsonBody = JSONObject().apply {
                put("email", email)
                put("password", password)
            }.toString()

            val requestBody = jsonBody.toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("apikey", supabaseAnonKey)
                .addHeader("Content-Type", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    try {
                        val jsonObj = JSONObject(bodyStr)
                        val userObj = jsonObj.optJSONObject("user")
                        val userEmail = userObj?.optString("email") ?: email
                        val emailPrefix = userEmail.substringBefore("@")
                        val name = emailPrefix.lowercase()
                            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                        Result.success(name)
                    } catch (e: Exception) {
                        Result.success(email.substringBefore("@").replaceFirstChar { it.uppercaseChar() })
                    }
                } else {
                    val errorMsg = try {
                        val json = JSONObject(bodyStr)
                        json.optString("error_description", json.optString("error", "Invalid login credentials"))
                    } catch (e: Exception) {
                        "Invalid login credentials"
                    }
                    Result.failure(Exception(errorMsg))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error logging in via Supabase", e)
            Result.failure(Exception("Check your internet connection and try again"))
        }
    }
}
