package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceSession
import com.example.data.AttendanceStorage
import com.example.data.StudentRepository
import com.example.util.PdfReportHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    department: String,
    subject: String,
    teacherName: String,
    onBack: () -> Unit,
    showSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0 = ANALYSIS, 1 = REPORT
    var allSessions by remember { mutableStateOf<List<AttendanceSession>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val coroutineScope = rememberCoroutineScope()

    // Reload internal attendance_master.json file asynchronously
    LaunchedEffect(Unit) {
        isLoading = true
        try {
            val sessions = AttendanceStorage.loadAllSessions(context)
            // Filter sessions matching currently selected department and subject
            allSessions = sessions.filter {
                it.department.trim().lowercase() == department.trim().lowercase() &&
                it.subject.trim().lowercase() == subject.trim().lowercase()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            showSnackbar("Failed to read historical attendance data.")
        } finally {
            isLoading = false
        }
    }

    val students = remember(department) {
        StudentRepository.getStudentsForDepartment(department)
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "ANALYTICS & REPORTS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF7DD3FC),
                                    letterSpacing = 1.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "$subject ($department)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF8FAFC)
                                )
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Go back",
                                tint = Color(0xFFF8FAFC)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A)
                    )
                )
                HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .padding(paddingValues)
        ) {
            // Interactive Tab Bar (ANALYSIS vs REPORT)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF0F172A),
                contentColor = Color(0xFF38BDF8)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "ANALYSIS",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTab == 0) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    },
                    modifier = Modifier.testTag("tab_analysis")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "REPORT",
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTab == 1) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    },
                    modifier = Modifier.testTag("tab_report")
                )
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Text(
                            "Reading attendance_master.json...",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        )
                    }
                }
            } else if (allSessions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "No records info",
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "No recorded sessions found for this subject and department.",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Go back and record student attendance first to populate historical analysis reports.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)),
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = onBack,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                        ) {
                            Text("Back to Configuration", color = Color.White)
                        }
                    }
                }
            } else {
                // Main Interactive Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (selectedTab == 0) {
                        AnalysisSection(
                            department = department,
                            subject = subject,
                            allSessions = allSessions,
                            students = students,
                            onSharePdf = {
                                try {
                                    PdfReportHelper.generateAndShareAnalysisReport(
                                        context = context,
                                        department = department,
                                        subject = subject,
                                        sessions = allSessions
                                    )
                                    showSnackbar("Preparing cumulative PDF report...")
                                } catch (e: Exception) {
                                    showSnackbar("Failed to build PDF report.")
                                }
                            }
                        )
                    } else {
                        ReportSection(
                            subject = subject,
                            teacherName = teacherName,
                            allSessions = allSessions,
                            onSharePdf = { selectedSession ->
                                try {
                                    PdfReportHelper.generateAndShareSessionReport(
                                        context = context,
                                        teacherName = teacherName,
                                        session = selectedSession
                                    )
                                    showSnackbar("Preparing session PDF report...")
                                } catch (e: Exception) {
                                    showSnackbar("Failed to build session PDF report.")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tab A: ANALYSIS section (Live cumulative metrics & Date Chips)
 */
@Composable
fun AnalysisSection(
    department: String,
    subject: String,
    allSessions: List<AttendanceSession>,
    students: List<com.example.data.Student>,
    onSharePdf: () -> Unit
) {
    val totalClasses = allSessions.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF0F172A)
            ),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Total Classes Taken",
                        style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF94A3B8))
                    )
                    Text(
                        "$totalClasses",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF7DD3FC)
                        )
                    )
                }

                Button(
                    onClick = onSharePdf,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF38BDF8),
                        contentColor = Color(0xFF020617)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        Text("Share PDF", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Horizontal Dates Chips list
        Column {
            Text(
                text = "Recorded Session Dates",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                ),
                modifier = Modifier.padding(bottom = 6.dp)
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(end = 16.dp)
            ) {
                items(allSessions) { session ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF2563EB).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Calendar",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = session.date,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF38BDF8)
                                )
                            )
                        }
                    }
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

        // Student metrics list
        Text(
            text = "CUMULATIVE STUDENT PERFORMANCE",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(students) { student ->
                val attendedCount = allSessions.count { it.records[student.usn] == true }
                val attendancePct = if (totalClasses > 0) {
                    (attendedCount.toDouble() / totalClasses) * 100
                } else {
                    0.0
                }

                val hasLowAttendance = attendancePct < 75.0 && totalClasses > 0
                val progressColor = if (hasLowAttendance) Color(0xFFEF4444) else Color(0xFF38BDF8)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF0F172A)
                    ),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = student.usn,
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(progressColor.copy(alpha = 0.12f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = String.format("%.1f%%", attendancePct),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = progressColor
                                    )
                                )
                            }
                        }

                        // Text Metric
                        Text(
                            text = "Attended: $attendedCount / $totalClasses Classes",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (hasLowAttendance) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                fontWeight = if (hasLowAttendance) FontWeight.SemiBold else FontWeight.Normal
                            )
                        )

                        // Sleek Progress Indicator dynamically colored
                        LinearProgressIndicator(
                            progress = if (totalClasses > 0) (attendedCount.toFloat() / totalClasses) else 0f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = progressColor,
                            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                        )

                        if (hasLowAttendance) {
                            Text(
                                text = "Critical shortage! Below minimum 75% requirement.",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFEF4444),
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab B: REPORT section (Specific session selector and report PDF generation)
 */
@Composable
fun ReportSection(
    subject: String,
    teacherName: String,
    allSessions: List<AttendanceSession>,
    onSharePdf: (AttendanceSession) -> Unit
) {
    var selectedSessionIndex by remember { mutableStateOf(0) }
    val currentSession = allSessions.getOrNull(selectedSessionIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Professional Report Selector Dropdown
        var expandedSelector by remember { mutableStateOf(false) }

        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Select Attendance Session Record",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                ),
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { expandedSelector = !expandedSelector },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFFF8FAFC),
                        containerColor = Color(0xFF0F172A)
                    ),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentSession?.let { "${it.date} (${it.timeSlot})" } ?: "No session selected",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text("Change", style = MaterialTheme.typography.bodySmall, color = Color(0xFF38BDF8))
                    }
                }

                DropdownMenu(
                    expanded = expandedSelector,
                    onDismissRequest = { expandedSelector = false },
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                ) {
                    allSessions.forEachIndexed { idx, s ->
                        DropdownMenuItem(
                            text = { Text("${s.date} - ${s.timeSlot} [${s.classType}]", color = Color(0xFFF8FAFC)) },
                            onClick = {
                                selectedSessionIndex = idx
                                expandedSelector = false
                            },
                            modifier = Modifier.background(Color(0xFF0F172A))
                        )
                    }
                }
            }
        }

        if (currentSession != null) {
            // Detailed stats block for selected session
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0F172A)
                ),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Session Summary",
                                style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = currentSession.date,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White)
                            )
                        }

                        // Share PDF button utilizing native sharing
                        Button(
                            onClick = { onSharePdf(currentSession) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF38BDF8),
                                contentColor = Color(0xFF020617)
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "PDF icon", modifier = Modifier.size(16.dp))
                                Text("Share Report", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.08f))

                    // Detail items
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            LabelValue("Teacher Name", teacherName)
                            Spacer(modifier = Modifier.height(8.dp))
                            LabelValue("Time Slot", currentSession.timeSlot)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            LabelValue("Class Type", currentSession.classType, alignRight = true)
                            Spacer(modifier = Modifier.height(8.dp))
                            LabelValue("Department", currentSession.department, alignRight = true)
                        }
                    }

                    // Tally indicators
                    val students = StudentRepository.getStudentsForDepartment(currentSession.department)
                    val totalCount = students.size
                    val presCount = currentSession.records.values.count { it }
                    val absCount = totalCount - presCount

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.2f))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MiniTallyBlock("Strength", "$totalCount", Color.White)
                        MiniTallyBlock("Present", "$presCount", Color(0xFF10B981))
                        MiniTallyBlock("Absent", "$absCount", Color(0xFFEF4444))
                    }
                }
            }

            // Quick view list of Present vs Absent students
            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

            Text(
                text = "ATTENDANCE SHEET AUDIT TRAIL",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            )

            val sessionStudents = StudentRepository.getStudentsForDepartment(currentSession.department)

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(sessionStudents) { student ->
                    val isPresent = currentSession.records[student.usn] ?: false
                    val statusText = if (isPresent) "PRESENT" else "ABSENT"
                    val statusColor = if (isPresent) Color(0xFF10B981) else Color(0xFFEF4444)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(student.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(student.usn, style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)))
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor.copy(alpha = 0.12f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabelValue(label: String, value: String, alignRight: Boolean = false) {
    Column(horizontalAlignment = if (alignRight) Alignment.End else Alignment.Start) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8)))
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
    }
}

@Composable
fun MiniTallyBlock(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = color))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8)))
    }
}
