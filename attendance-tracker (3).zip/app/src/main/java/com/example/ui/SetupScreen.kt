package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    teacherName: String,
    onNavigateToMarking: (dept: String, subj: String, slot: String, type: String) -> Unit,
    onNavigateToAnalytics: (dept: String, subj: String) -> Unit,
    onLogout: () -> Unit
) {
    // Dropdown Choices
    val timeSlots = listOf(
        "09:30 AM to 10:30 AM",
        "10:30 AM to 11:30 AM",
        "11:45 AM to 12:45 PM",
        "12:45 PM to 01:45 PM",
        "02:30 PM to 04:30 PM"
    )

    val classTypes = listOf("Theory", "Lab")

    val departments = listOf(
        "Computer Science & Engg",
        "Electronic & Communication Engg",
        "Mechanical Engg",
        "Civil Engg",
        "Electrical & Electronic Engg"
    )

    val subjectsMap = mapOf(
        "Computer Science & Engg" to listOf(
            "BCS701 - Internet of Things",
            "BCS702 - Parallel Computing",
            "BCS703 - Cryptography & Network Security",
            "BCS714D - Big Data Analytics"
        ),
        "Electronic & Communication Engg" to listOf(
            "BEC701 - VLSI",
            "BEC702 - ECS"
        ),
        "Civil Engg" to listOf(
            "BCV701 - Construction materials",
            "BCV702 - Building construction"
        ),
        "Mechanical Engg" to listOf(
            "BME701 - Non traditional machining",
            "BME702 - Non conventional sources"
        ),
        "Electrical & Electronic Engg" to listOf(
            "BEE701 - PCB designing",
            "BEE702 - Wire Science"
        )
    )

    // States
    var selectedTimeSlot by remember { mutableStateOf("") }
    var selectedClassType by remember { mutableStateOf("") }
    var selectedDepartment by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf("") }

    // Reset subject if department changes
    val enabledSubjects = subjectsMap[selectedDepartment] ?: emptyList()
    LaunchedEffect(selectedDepartment) {
        selectedSubject = ""
    }

    val isAllChosen = selectedTimeSlot.isNotEmpty() &&
            selectedClassType.isNotEmpty() &&
            selectedDepartment.isNotEmpty() &&
            selectedSubject.isNotEmpty()

    val isAnalyticsEnabled = selectedDepartment.isNotEmpty() && selectedSubject.isNotEmpty()

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(
                            text = "Welcome $teacherName",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF8FAFC)
                            )
                        )
                    },
                    actions = {
                        TextButton(onClick = onLogout) {
                            Text("Logout", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A)
                    )
                )
                HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .padding(paddingValues)
                .padding(horizontal = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Header description
                Text(
                    text = "Configure the active session parameters below to initialize student list verification.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                // TIME SLOT DROPDOWN
                DropdownSection(
                    label = "Select Time Slot",
                    selectedValue = selectedTimeSlot,
                    items = timeSlots,
                    onValueSelected = { selectedTimeSlot = it },
                    icon = Icons.Default.Schedule,
                    testTag = "timeslot_dropdown"
                )

                // CLASS TYPE DROPDOWN
                DropdownSection(
                    label = "Class Type",
                    selectedValue = selectedClassType,
                    items = classTypes,
                    onValueSelected = { selectedClassType = it },
                    icon = Icons.Default.Class,
                    testTag = "classtype_dropdown"
                )

                // DEPARTMENT DROPDOWN
                DropdownSection(
                    label = "Select Department",
                    selectedValue = selectedDepartment,
                    items = departments,
                    onValueSelected = { selectedDepartment = it },
                    icon = Icons.Default.Group,
                    testTag = "department_dropdown"
                )

                // SUBJECT DROPDOWN (dynamically enabled)
                DropdownSection(
                    label = "Select Academic Subject",
                    selectedValue = selectedSubject,
                    items = enabledSubjects,
                    onValueSelected = { selectedSubject = it },
                    icon = Icons.Default.MenuBook,
                    enabled = selectedDepartment.isNotEmpty(),
                    placeholder = if (selectedDepartment.isEmpty()) "Select Department first" else "Choose subject",
                    testTag = "subject_dropdown"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons container
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // PRIMARY ACTION: Mark Attendance
                    Button(
                        onClick = {
                            if (isAllChosen) {
                                onNavigateToMarking(
                                    selectedDepartment,
                                    selectedSubject,
                                    selectedTimeSlot,
                                    selectedClassType
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("mark_attendance_button"),
                        enabled = isAllChosen,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF38BDF8), // Sky Blue highlight
                            contentColor = Color(0xFF020617),
                            disabledContainerColor = Color(0xFF0F172A),
                            disabledContentColor = Color(0xFF64748B)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "Initialize Attendance Sheet",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Arrow Forward"
                            )
                        }
                    }

                    // SECONDARY ACTION: View Analytics directly
                    OutlinedButton(
                        onClick = {
                            if (isAnalyticsEnabled) {
                                onNavigateToAnalytics(selectedDepartment, selectedSubject)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("view_analytics_button"),
                        enabled = isAnalyticsEnabled,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF38BDF8),
                            disabledContentColor = Color(0xFF64748B)
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isAnalyticsEnabled) Color(0xFF38BDF8) else Color(0xFF1E293B)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Analytics Icon"
                            )
                            Text(
                                "ANALYTICS & REPORTS DASHBOARD",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownSection(
    label: String,
    selectedValue: String,
    items: List<String>,
    onValueSelected: (String) -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    placeholder: String = "Select option",
    testTag: String = ""
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = if (enabled) Color(0xFF38BDF8) else Color(0xFF64748B)
            ),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        ExposedDropdownMenuBox(
            expanded = expanded && enabled,
            onExpandedChange = { if (enabled) expanded = !expanded }
        ) {
            OutlinedTextField(
                value = selectedValue,
                onValueChange = {},
                readOnly = true,
                enabled = enabled,
                placeholder = { Text(placeholder, color = Color(0xFF64748B)) },
                leadingIcon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (enabled) Color(0xFF38BDF8) else Color(0xFF64748B)
                    )
                },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF1E293B),
                    disabledBorderColor = Color(0xFF0F172A),
                    focusedTextColor = Color(0xFFF8FAFC),
                    unfocusedTextColor = Color(0xFFF8FAFC),
                    disabledTextColor = Color(0xFF64748B),
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A),
                    disabledContainerColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            ExposedDropdownMenu(
                expanded = expanded && enabled,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color(0xFF0F172A))
            ) {
                items.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item, color = Color(0xFFF8FAFC)) },
                        onClick = {
                            onValueSelected(item)
                            expanded = false
                        },
                        modifier = Modifier.background(Color(0xFF0F172A))
                    )
                }
            }
        }
    }
}
