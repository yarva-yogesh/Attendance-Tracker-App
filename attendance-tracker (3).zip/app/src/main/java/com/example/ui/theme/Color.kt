package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Colors (Slate and Sky Blue)
val SleekBackground = Color(0xFF020617)     // Deep Dark Navy
val SleekSurface = Color(0xFF0F172A)        // Slate 900 Card/Header
val SleekBorder = Color(0xFF1E293B)         // Slate 800 Border
val SleekPrimary = Color(0xFF38BDF8)        // Sky Blue Accent
val SleekSecondary = Color(0xFF7DD3FC)      // Soft Sky Blue Accent
val SleekRoyalBlue = Color(0xFF1E4ED8)      // Royal Blue Accent
val SleekDeepBlue = Color(0xFF1E3A8A)       // Deep Royal Blue
val SleekTextPrimary = Color(0xFFF8FAFC)    // Clean Slate 50 Text
val SleekTextSecondary = Color(0xFF94A3B8)  // Slate 400 Subtitle Text
val SleekTextMuted = Color(0xFF64748B)      // Slate 500 Muted Text

// Keep standard names to avoid breaking dependencies, but point to Sleek Theme values
val LightPrimary = Color(0xFF1E4ED8)
val LightSecondary = Color(0xFF38BDF8)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF020617)
val LightOnSurface = Color(0xFF020617)

val DarkBackground = SleekBackground
val DarkSurface = SleekSurface
val DarkPrimary = SleekPrimary
val DarkSecondary = SleekRoyalBlue
val DarkOnBackground = SleekTextPrimary
val DarkOnSurface = SleekTextPrimary

val SapphireBlue = SleekRoyalBlue
val DarkSapphireBlue = SleekSecondary

