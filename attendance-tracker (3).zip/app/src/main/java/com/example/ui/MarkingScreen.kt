package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AttendanceSession
import com.example.data.AttendanceStorage
import com.example.data.StudentRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarkingScreen(
    department: String,
    subject: String,
    timeSlot: String,
    classType: String,
    onBack: () -> Unit,
    onSubmitSuccess: () -> Unit,
    showSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Load students for department
    val students = remember(department) {
        StudentRepository.getStudentsForDepartment(department)
    }

    // Attendance records state: USN -> present (true/false)
    val attendanceRecords = remember {
        mutableStateMapOf<String, Boolean>().apply {
            students.forEach { put(it.usn, true) } // default to Present
        }
    }

    // Visual Counters
    val totalStrength = students.size
    val presentCount = attendanceRecords.values.count { it }
    val absentCount = totalStrength - presentCount

    var showSummaryDialog by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "MARKING SHEET",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF7DD3FC),
                                    letterSpacing = 1.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = subject,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF8FAFC)
                                )
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Go back",
                                tint = Color(0xFFF8FAFC)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A)
                    )
                )
                HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)
            }
        },
        bottomBar = {
            Column {
                HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    color = Color(0xFF0F172A)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = { showSummaryDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("review_session_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF38BDF8), // Sky Blue
                                contentColor = Color(0xFF020617)    // Deep slate
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = "Review Session Summary",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .padding(paddingValues)
        ) {
            // Sleek Counters Row matching Design HTML
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Card 1: Present
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E4ED8).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "PRESENT",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF94A3B8),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$presentCount",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color(0xFF7DD3FC),
                                fontWeight = FontWeight.Black
                            )
                        )
                    }
                }

                // Card 2: Absent
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, Color(0xFF1E4ED8).copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "ABSENT",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF94A3B8),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$absentCount",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color(0xFF94A3B8),
                                fontWeight = FontWeight.Black
                            )
                        )
                    }
                }

                // Card 3: Ratio
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E4ED8))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "RATIO",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFDBEAFE),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$presentCount/$totalStrength",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        )
                    }
                }
            }

            // Student List Header label
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STUDENT LIST (${students.size})",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                )
                TextButton(
                    onClick = {
                        val allPresent = attendanceRecords.values.all { it }
                        students.forEach { student ->
                            attendanceRecords[student.usn] = !allPresent
                        }
                    }
                ) {
                    Text(
                        text = if (attendanceRecords.values.all { it }) "Deselect All" else "Select All",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            // Student List View with smooth inertia scrolling built-in
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 24.dp)
                    .testTag("student_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(students, key = { it.usn }) { student ->
                    val isChecked = attendanceRecords[student.usn] ?: false

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F172A))
                            .border(
                                width = 1.dp,
                                color = if (isChecked) Color(0xFF38BDF8).copy(alpha = 0.3f) else Color(0xFF1E293B),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { attendanceRecords[student.usn] = !isChecked }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Avatar block
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isChecked) Color(0xFF1E3A8A) else Color(0xFF1E293B).copy(alpha = 0.5f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isChecked) Color(0xFF38BDF8).copy(alpha = 0.3f) else Color(0xFF1E293B),
                                        shape = RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.name.take(2).uppercase(),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isChecked) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                                    )
                                )
                            }

                            Column {
                                Text(
                                    text = student.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isChecked) Color(0xFFF8FAFC) else Color(0xFFF8FAFC).copy(alpha = 0.6f)
                                    )
                                )
                                Text(
                                    text = student.usn,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                        color = if (isChecked) Color(0xFF7DD3FC) else Color(0xFF94A3B8).copy(alpha = 0.5f)
                                    )
                                )
                            }
                        }

                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { attendanceRecords[student.usn] = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = Color(0xFF38BDF8),
                                uncheckedColor = Color(0xFF1E293B),
                                checkmarkColor = Color(0xFF020617)
                            ),
                            modifier = Modifier.testTag("checkbox_${student.usn}")
                        )
                    }
                }
                
                // Extra margin at the bottom for scroll comfort
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }

    // Modal AlertDialog for Summary Review
    if (showSummaryDialog) {
        val presentPct = if (totalStrength > 0) (presentCount.toFloat() / totalStrength) else 0f

        AlertDialog(
            onDismissRequest = { if (!isSaving) showSummaryDialog = false },
            title = {
                Text(
                    text = "Session Summary Review",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Verify attendance distribution before locally archiving the session record.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )

                    // Graphical Circular Chart representation
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(130.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Grey background circle
                            drawCircle(
                                color = Color.Gray.copy(alpha = 0.15f),
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Green Present arc
                            drawArc(
                                color = Color(0xFF10B981),
                                startAngle = -90f,
                                sweepAngle = presentPct * 360f,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${(presentPct * 100).toInt()}%",
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF10B981)
                            )
                            Text(
                                text = "Present",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }

                    // Numeric stats tally
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatRow("Total Students", "$totalStrength", MaterialTheme.colorScheme.onSurface)
                        StatRow("Present Tally", "$presentCount", Color(0xFF10B981))
                        StatRow("Absent Tally", "$absentCount", Color(0xFFEF4444))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSaving = true
                        coroutineScope.launch {
                            val currentDate = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                            val session = AttendanceSession(
                                id = System.currentTimeMillis(),
                                date = currentDate,
                                department = department,
                                subject = subject,
                                timeSlot = timeSlot,
                                classType = classType,
                                records = attendanceRecords.toMap()
                            )

                            val success = AttendanceStorage.saveSession(context, session)
                            if (success) {
                                showSnackbar("Attendance recorded successfully!")
                                showSummaryDialog = false
                                onSubmitSuccess()
                            } else {
                                showSnackbar("Failed to write offline records. Please check storage permission.")
                            }
                            isSaving = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF10B981), // Green check submit
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("dialog_confirm_button"),
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text("Confirm & Submit")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showSummaryDialog = false },
                    enabled = !isSaving,
                    modifier = Modifier.testTag("dialog_cancel_button")
                ) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
        )
    }
}

@Composable
fun CounterBox(value: Int, label: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = "$value",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = color.copy(alpha = 0.8f)
            )
        )
    }
}

@Composable
fun StatRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        )
    }
}
