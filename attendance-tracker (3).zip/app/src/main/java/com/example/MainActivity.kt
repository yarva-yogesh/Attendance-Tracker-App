package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.AnalyticsScreen
import com.example.ui.LoginScreen
import com.example.ui.MarkingScreen
import com.example.ui.SetupScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

sealed interface Screen {
    object Login : Screen
    data class Setup(val teacherName: String, val teacherEmail: String) : Screen
    data class Marking(
        val teacherName: String,
        val department: String,
        val subject: String,
        val timeSlot: String,
        val classType: String
    ) : Screen
    data class Analytics(
        val teacherName: String,
        val department: String,
        val subject: String
    ) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Login) }
                val snackbarHostState = remember { SnackbarHostState() }
                val coroutineScope = rememberCoroutineScope()

                val showSnackbar: (String) -> Unit = { message ->
                    coroutineScope.launch {
                        snackbarHostState.currentSnackbarData?.dismiss()
                        snackbarHostState.showSnackbar(message)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (val screen = currentScreen) {
                            is Screen.Login -> {
                                LoginScreen(
                                    onLoginSuccess = { name, email ->
                                        currentScreen = Screen.Setup(name, email)
                                        showSnackbar("Authenticated as $name successfully.")
                                    },
                                    showSnackbar = showSnackbar
                                )
                            }
                            is Screen.Setup -> {
                                SetupScreen(
                                    teacherName = screen.teacherName,
                                    onNavigateToMarking = { dept, subj, slot, type ->
                                        currentScreen = Screen.Marking(
                                            teacherName = screen.teacherName,
                                            department = dept,
                                            subject = subj,
                                            timeSlot = slot,
                                            classType = type
                                        )
                                    },
                                    onNavigateToAnalytics = { dept, subj ->
                                        currentScreen = Screen.Analytics(
                                            teacherName = screen.teacherName,
                                            department = dept,
                                            subject = subj
                                        )
                                    },
                                    onLogout = {
                                        currentScreen = Screen.Login
                                        showSnackbar("Logged out securely.")
                                    }
                                )
                            }
                            is Screen.Marking -> {
                                MarkingScreen(
                                    department = screen.department,
                                    subject = screen.subject,
                                    timeSlot = screen.timeSlot,
                                    classType = screen.classType,
                                    onBack = {
                                        currentScreen = Screen.Setup(screen.teacherName, "")
                                    },
                                    onSubmitSuccess = {
                                        currentScreen = Screen.Analytics(
                                            teacherName = screen.teacherName,
                                            department = screen.department,
                                            subject = screen.subject
                                        )
                                    },
                                    showSnackbar = showSnackbar
                                )
                            }
                            is Screen.Analytics -> {
                                AnalyticsScreen(
                                    department = screen.department,
                                    subject = screen.subject,
                                    teacherName = screen.teacherName,
                                    onBack = {
                                        currentScreen = Screen.Setup(screen.teacherName, "")
                                    },
                                    showSnackbar = showSnackbar
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
