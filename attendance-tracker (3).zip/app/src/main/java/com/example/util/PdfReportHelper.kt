package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.AttendanceSession
import com.example.data.Student
import com.example.data.StudentRepository
import java.io.File
import java.io.FileOutputStream

object PdfReportHelper {

    /**
     * A helper state class to manage multi-page drawing bounds during PDF report generation.
     */
    private class PageState(
        val pdfDocument: PdfDocument,
        val paint: Paint,
        val textPaint: Paint
    ) {
        var pageNum = 1
        var pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNum).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas
        var currentY = 142f

        fun advancePage(primaryAccentColor: String, titleSuffix: String) {
            // Draw footer on current page before finishing
            textPaint.apply {
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
                textSize = 8f
                color = Color.GRAY
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Generated secure offline report via institutional Attendance Tracker App.", 297.5f, 810f, textPaint)

            pdfDocument.finishPage(page)

            pageNum++
            pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNum).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas

            // Draw header band on the new page
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor(primaryAccentColor)
            canvas.drawRect(20f, 20f, 575f, 35f, paint)

            textPaint.apply {
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textSize = 12f
                color = Color.parseColor("#1E3A8A")
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("$titleSuffix (Page $pageNum)", 297.5f, 55f, textPaint)

            paint.color = Color.LTGRAY
            paint.strokeWidth = 1.5f
            canvas.drawLine(40f, 65f, 555f, 65f, paint)

            currentY = 85f
        }
    }

    /**
     * Generates and shares the Session Detailed Report.
     */
    fun generateAndShareSessionReport(
        context: Context,
        teacherName: String,
        session: AttendanceSession
    ) {
        val pdfDocument = PdfDocument()
        val paint = Paint()
        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val state = PageState(pdfDocument, paint, textPaint)
        state.currentY = 142f

        // Draw background accent on first page
        paint.color = Color.parseColor("#0F172A") // Dark Navy Accent
        state.canvas.drawRect(20f, 20f, 575f, 40f, paint)

        // Draw Header
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 20f
            color = Color.parseColor("#1E3A8A") // Royal Blue
            textAlign = Paint.Align.CENTER
        }
        state.canvas.drawText("Attendance Tracker", 297.5f, 75f, textPaint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textSize = 12f
            color = Color.DKGRAY
        }
        state.canvas.drawText("Official Academic Attendance Record Summary", 297.5f, 95f, textPaint)

        // Draw Divider
        paint.color = Color.LTGRAY
        paint.strokeWidth = 1.5f
        state.canvas.drawLine(40f, 110f, 555f, 110f, paint)

        // Meta Grid Box
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 10f
        textPaint.color = Color.BLACK
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)

        val metaXLeft = 50f
        val metaXRight = 320f

        // Draw Meta Box borders
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#1D4ED8") // Royal Blue border
        state.canvas.drawRect(40f, 120f, 555f, 235f, paint)
        paint.style = Paint.Style.FILL

        state.canvas.drawText("Subject Name:  ${session.subject}", metaXLeft, state.currentY, textPaint)
        state.canvas.drawText("Teacher Name:  $teacherName", metaXRight, state.currentY, textPaint)
        state.currentY += 22f
        state.canvas.drawText("Session Date:  ${session.date}", metaXLeft, state.currentY, textPaint)
        state.canvas.drawText("Time Slot:     ${session.timeSlot}", metaXRight, state.currentY, textPaint)
        state.currentY += 22f
        state.canvas.drawText("Class Type:    ${session.classType}", metaXLeft, state.currentY, textPaint)
        state.canvas.drawText("Department:    ${session.department}", metaXRight, state.currentY, textPaint)
        state.currentY += 22f

        val students = StudentRepository.getStudentsForDepartment(session.department)
        val totalStrength = students.size
        val countPresent = session.records.values.count { it }
        val countAbsent = totalStrength - countPresent

        state.canvas.drawText("Total Strength: $totalStrength", metaXLeft, state.currentY, textPaint)
        state.canvas.drawText("Present: $countPresent | Absent: $countAbsent", metaXRight, state.currentY, textPaint)

        state.currentY = 270f

        // LIST OF PRESENT STUDENTS Table Title & Headers
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 12f
            color = Color.parseColor("#15803D") // Dark Green for Present
            textAlign = Paint.Align.LEFT
        }
        state.canvas.drawText("LIST OF PRESENT STUDENTS", 40f, state.currentY, textPaint)
        state.currentY += 15f

        // Draw Table Header
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#DCFCE7") // Light green background
        state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 20f, paint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 9f
            color = Color.parseColor("#14532D")
        }
        state.canvas.drawText("Sl. No.", 50f, state.currentY + 14f, textPaint)
        state.canvas.drawText("Student Name", 110f, state.currentY + 14f, textPaint)
        state.canvas.drawText("USN / Roll Number", 380f, state.currentY + 14f, textPaint)

        state.currentY += 20f

        var presentIndex = 1
        for (student in students) {
            val isPresent = session.records[student.usn] ?: false
            if (isPresent) {
                // Check if we need to advance page
                if (state.currentY + 18f > 780f) {
                    state.advancePage("#0F172A", "Attendance Tracker")

                    // Draw Continued Table Header on fresh page
                    textPaint.apply {
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        textSize = 12f
                        color = Color.parseColor("#15803D")
                        textAlign = Paint.Align.LEFT
                    }
                    state.canvas.drawText("LIST OF PRESENT STUDENTS (Continued)", 40f, state.currentY, textPaint)
                    state.currentY += 15f

                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#DCFCE7")
                    state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 20f, paint)

                    textPaint.apply {
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        textSize = 9f
                        color = Color.parseColor("#14532D")
                    }
                    state.canvas.drawText("Sl. No.", 50f, state.currentY + 14f, textPaint)
                    state.canvas.drawText("Student Name", 110f, state.currentY + 14f, textPaint)
                    state.canvas.drawText("USN / Roll Number", 380f, state.currentY + 14f, textPaint)

                    state.currentY += 20f
                }

                // Draw row item
                paint.style = Paint.Style.FILL
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                textPaint.color = Color.BLACK
                textPaint.textAlign = Paint.Align.LEFT

                if (presentIndex % 2 == 0) {
                    paint.color = Color.parseColor("#F0FDF4")
                    state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 18f, paint)
                }
                state.canvas.drawText("$presentIndex", 50f, state.currentY + 13f, textPaint)
                state.canvas.drawText(student.name, 110f, state.currentY + 13f, textPaint)
                state.canvas.drawText(student.usn, 380f, state.currentY + 13f, textPaint)
                state.currentY += 18f
                presentIndex++
            }
        }
        if (presentIndex == 1) {
            state.canvas.drawText("No students present in this session.", 50f, state.currentY + 13f, textPaint)
            state.currentY += 18f
        }

        // Adjust space for the absent header or start fresh page
        if (state.currentY + 45f > 780f) {
            state.advancePage("#0F172A", "Attendance Tracker")
        } else {
            state.currentY += 20f
        }

        // LIST OF ABSENT STUDENTS Table Title & Headers
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 12f
            color = Color.parseColor("#B91C1C") // Dark Red for Absent
            textAlign = Paint.Align.LEFT
        }
        state.canvas.drawText("LIST OF ABSENT STUDENTS", 40f, state.currentY, textPaint)
        state.currentY += 15f

        // Draw Table Header
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#FEE2E2") // Light red background
        state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 20f, paint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 9f
            color = Color.parseColor("#7F1D1D")
        }
        state.canvas.drawText("Sl. No.", 50f, state.currentY + 14f, textPaint)
        state.canvas.drawText("Student Name", 110f, state.currentY + 14f, textPaint)
        state.canvas.drawText("USN / Roll Number", 380f, state.currentY + 14f, textPaint)

        state.currentY += 20f

        var absentIndex = 1
        for (student in students) {
            val isPresent = session.records[student.usn] ?: false
            if (!isPresent) {
                // Check if we need to advance page
                if (state.currentY + 18f > 780f) {
                    state.advancePage("#0F172A", "Attendance Tracker")

                    // Draw Continued Table Header on fresh page
                    textPaint.apply {
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        textSize = 12f
                        color = Color.parseColor("#B91C1C")
                        textAlign = Paint.Align.LEFT
                    }
                    state.canvas.drawText("LIST OF ABSENT STUDENTS (Continued)", 40f, state.currentY, textPaint)
                    state.currentY += 15f

                    paint.style = Paint.Style.FILL
                    paint.color = Color.parseColor("#FEE2E2")
                    state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 20f, paint)

                    textPaint.apply {
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        textSize = 9f
                        color = Color.parseColor("#7F1D1D")
                    }
                    state.canvas.drawText("Sl. No.", 50f, state.currentY + 14f, textPaint)
                    state.canvas.drawText("Student Name", 110f, state.currentY + 14f, textPaint)
                    state.canvas.drawText("USN / Roll Number", 380f, state.currentY + 14f, textPaint)

                    state.currentY += 20f
                }

                // Draw row item
                paint.style = Paint.Style.FILL
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                textPaint.color = Color.BLACK
                textPaint.textAlign = Paint.Align.LEFT

                if (absentIndex % 2 == 0) {
                    paint.color = Color.parseColor("#FEF2F2")
                    state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 18f, paint)
                }
                state.canvas.drawText("$absentIndex", 50f, state.currentY + 13f, textPaint)
                state.canvas.drawText(student.name, 110f, state.currentY + 13f, textPaint)
                state.canvas.drawText(student.usn, 380f, state.currentY + 13f, textPaint)
                state.currentY += 18f
                absentIndex++
            }
        }
        if (absentIndex == 1) {
            state.canvas.drawText("All students were present in this session.", 50f, state.currentY + 13f, textPaint)
            state.currentY += 18f
        }

        // Draw footer note on final page
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            textSize = 8f
            color = Color.GRAY
            textAlign = Paint.Align.CENTER
        }
        state.canvas.drawText("Generated secure offline report via institutional Attendance Tracker App.", 297.5f, 810f, textPaint)

        pdfDocument.finishPage(state.page)

        // Save to cache and share
        val tempFile = File(context.cacheDir, "attendance_session_report_${session.id}.pdf")
        try {
            FileOutputStream(tempFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            shareFile(context, tempFile, "Session Attendance Report - ${session.date}")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Generates and shares the Cumulative Analysis Report (Section A).
     */
    fun generateAndShareAnalysisReport(
        context: Context,
        department: String,
        subject: String,
        sessions: List<AttendanceSession>
    ) {
        val pdfDocument = PdfDocument()
        val paint = Paint()
        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        val state = PageState(pdfDocument, paint, textPaint)
        state.currentY = 142f

        // Draw background accent on first page
        paint.color = Color.parseColor("#1D4ED8") // Royal Blue Accent
        state.canvas.drawRect(20f, 20f, 575f, 40f, paint)

        // Draw Header
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 20f
            color = Color.parseColor("#1E293B")
            textAlign = Paint.Align.CENTER
        }
        state.canvas.drawText("Attendance Tracker Report", 297.5f, 75f, textPaint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textSize = 12f
            color = Color.DKGRAY
        }
        state.canvas.drawText("Official Academic Attendance Record Summary", 297.5f, 95f, textPaint)

        // Draw Divider
        paint.color = Color.LTGRAY
        paint.strokeWidth = 1.5f
        state.canvas.drawLine(40f, 110f, 555f, 110f, paint)

        // Meta Box
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 10f
        textPaint.color = Color.BLACK
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)

        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#1E293B") // Navy border
        state.canvas.drawRect(40f, 120f, 555f, 185f, paint)
        paint.style = Paint.Style.FILL

        val metaXLeft = 50f
        val metaXRight = 320f

        state.canvas.drawText("Department:  $department", metaXLeft, state.currentY, textPaint)
        state.canvas.drawText("Subject Name:  $subject", metaXRight, state.currentY, textPaint)
        state.currentY += 22f

        val totalClasses = sessions.size
        val sessionDates = sessions.map { it.date }.distinct().joinToString(", ")
        state.canvas.drawText("Total Classes Taken: $totalClasses", metaXLeft, state.currentY, textPaint)

        val datesStr = if (sessionDates.length > 35) sessionDates.take(32) + "..." else sessionDates
        state.canvas.drawText("Recorded Dates: $datesStr", metaXRight, state.currentY, textPaint)

        state.currentY = 220f

        // CUMULATIVE METRICS TABLE
        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 12f
            color = Color.parseColor("#1E3A8A") // Royal Blue
            textAlign = Paint.Align.LEFT
        }
        state.canvas.drawText("STUDENT CUMULATIVE ATTENDANCE STATUS", 40f, state.currentY, textPaint)
        state.currentY += 15f

        // Draw Table Header
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#E2E8F0") // Slate Light Background
        state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 22f, paint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 9f
            color = Color.parseColor("#0F172A")
        }
        state.canvas.drawText("Sl.", 50f, state.currentY + 15f, textPaint)
        state.canvas.drawText("USN / Roll Number", 85f, state.currentY + 15f, textPaint)
        state.canvas.drawText("Student Name", 200f, state.currentY + 15f, textPaint)
        state.canvas.drawText("Attended / Total", 380f, state.currentY + 15f, textPaint)
        state.canvas.drawText("Percentage", 480f, state.currentY + 15f, textPaint)

        state.currentY += 22f

        val students = StudentRepository.getStudentsForDepartment(department)
        var studentIndex = 1
        for (student in students) {
            val attendedCount = sessions.count { it.records[student.usn] == true }
            val percentage = if (totalClasses > 0) {
                (attendedCount.toDouble() / totalClasses) * 100
            } else {
                0.0
            }

            // Check if we need to advance page
            if (state.currentY + 20f > 780f) {
                state.advancePage("#1D4ED8", "Attendance Tracker Report")

                // Draw Continued Table Header on fresh page
                textPaint.apply {
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    textSize = 12f
                    color = Color.parseColor("#1E3A8A")
                    textAlign = Paint.Align.LEFT
                }
                state.canvas.drawText("STUDENT CUMULATIVE ATTENDANCE STATUS (Continued)", 40f, state.currentY, textPaint)
                state.currentY += 15f

                paint.style = Paint.Style.FILL
                paint.color = Color.parseColor("#E2E8F0")
                state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 22f, paint)

                textPaint.apply {
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    textSize = 9f
                    color = Color.parseColor("#0F172A")
                }
                state.canvas.drawText("Sl.", 50f, state.currentY + 15f, textPaint)
                state.canvas.drawText("USN / Roll Number", 85f, state.currentY + 15f, textPaint)
                state.canvas.drawText("Student Name", 200f, state.currentY + 15f, textPaint)
                state.canvas.drawText("Attended / Total", 380f, state.currentY + 15f, textPaint)
                state.canvas.drawText("Percentage", 480f, state.currentY + 15f, textPaint)

                state.currentY += 22f
            }

            paint.style = Paint.Style.FILL
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.color = Color.BLACK
            textPaint.textAlign = Paint.Align.LEFT

            // Alternating Row backgrounds
            if (studentIndex % 2 == 0) {
                paint.color = Color.parseColor("#F8FAFC")
                state.canvas.drawRect(40f, state.currentY, 555f, state.currentY + 20f, paint)
            }

            state.canvas.drawText("$studentIndex", 50f, state.currentY + 14f, textPaint)
            state.canvas.drawText(student.usn, 85f, state.currentY + 14f, textPaint)
            state.canvas.drawText(student.name, 200f, state.currentY + 14f, textPaint)
            state.canvas.drawText("$attendedCount / $totalClasses", 380f, state.currentY + 14f, textPaint)

            // Highlight low attendance (<75%) in red
            val pctStr = String.format("%.1f%%", percentage)
            if (percentage < 75.0 && totalClasses > 0) {
                val tempColor = textPaint.color
                textPaint.color = Color.RED
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                state.canvas.drawText(pctStr, 480f, state.currentY + 14f, textPaint)
                textPaint.color = tempColor
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            } else {
                state.canvas.drawText(pctStr, 480f, state.currentY + 14f, textPaint)
            }

            state.currentY += 20f
            studentIndex++
        }

        // Space for visual legend at bottom
        if (state.currentY + 40f > 780f) {
            state.advancePage("#1D4ED8", "Attendance Tracker Report")
        } else {
            state.currentY += 25f
        }

        textPaint.apply {
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            textSize = 8f
            color = Color.DKGRAY
            textAlign = Paint.Align.LEFT
        }
        state.canvas.drawText("* Note: Attendance percentages below 75.0% are highlighted and may denote critical shortages.", 45f, state.currentY, textPaint)

        // Footer note on final page
        textPaint.apply {
            textSize = 8f
            color = Color.GRAY
            textAlign = Paint.Align.CENTER
        }
        state.canvas.drawText("Generated secure offline report via institutional Attendance Tracker App.", 297.5f, 810f, textPaint)

        pdfDocument.finishPage(state.page)

        // Save to cache and share
        val tempFile = File(context.cacheDir, "attendance_analysis_report_${System.currentTimeMillis()}.pdf")
        try {
            FileOutputStream(tempFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()
            shareFile(context, tempFile, "Cumulative Attendance Analysis Report")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareFile(context: Context, file: File, subjectText: String) {
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, file)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subjectText)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Attendance Report via..."))
    }
}
