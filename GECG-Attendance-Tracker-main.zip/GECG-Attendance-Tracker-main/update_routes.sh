sed -i 's/const val ATTENDANCE = "attendance\/{department}\/{subject}"/const val ATTENDANCE = "attendance\/{department}\/{subject}\/{teacher}"/' app/src/main/java/com/example/ui/screens/Screens.kt
sed -i 's/const val DASHBOARD = "dashboard\/{department}\/{subject}"/const val DASHBOARD = "dashboard\/{department}\/{subject}\/{teacher}"/' app/src/main/java/com/example/ui/screens/Screens.kt
sed -i 's/fun createAttendanceRoute(department: String, subject: String): String {/fun createAttendanceRoute(department: String, subject: String, teacher: String): String {/' app/src/main/java/com/example/ui/screens/Screens.kt
sed -i 's/return "attendance\/$department\/$subject"/return "attendance\/$department\/$subject\/$teacher"/' app/src/main/java/com/example/ui/screens/Screens.kt
sed -i 's/fun createDashboardRoute(department: String, subject: String): String {/fun createDashboardRoute(department: String, subject: String, teacher: String): String {/' app/src/main/java/com/example/ui/screens/Screens.kt
sed -i 's/return "dashboard\/$department\/$subject"/return "dashboard\/$department\/$subject\/$teacher"/' app/src/main/java/com/example/ui/screens/Screens.kt
