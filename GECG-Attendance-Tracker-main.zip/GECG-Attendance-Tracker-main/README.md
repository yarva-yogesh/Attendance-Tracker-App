# GECG Attendance Tracker

A sleek, robust, mobile-first Jetpack Compose application designed for Government Engineering College - Gangavathi. 

## Design System
- **Theme**: "Professional Polish" with high-contrast Deep Navy and Sky Blue accents.
- **Components**: Adheres to modern Material 3 conventions, replacing defaults with fully customized styling to match the provided specs.

## Architecture
- **Multi-File Organization**: Dedicated files for `Screens`, `Storage`, `Theme`, `Models`, and `Utils`.
- **Hybrid Auth Interface**: Ready for direct connection to Supabase authentication (currently a visual interface with validation logic mapped).
- **Offline Persistence**: Implemented `AttendanceStorage` for writing and parsing `attendance_master.json` files locally.
- **Reporting**: Features an on-device PDF generator built with native Canvas printing, ready to export and share.
