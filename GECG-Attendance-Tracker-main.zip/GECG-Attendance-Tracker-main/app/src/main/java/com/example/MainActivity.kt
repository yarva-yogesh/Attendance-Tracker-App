package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import java.net.URLDecoder
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    
                    NavHost(
                        navController = navController,
                        startDestination = Routes.LOGIN
                    ) {
                        composable(Routes.LOGIN) {
                            LoginScreen(
                                onLoginSuccess = { email ->
                                    val safeEmail = URLEncoder.encode(email, "UTF-8")
                                    navController.navigate(Routes.createSetupRoute(safeEmail)) {
                                        popUpTo(Routes.LOGIN) { inclusive = true }
                                    }
                                }
                            )
                        }
                        
                        composable(Routes.SETUP) { backStackEntry ->
                            val safeUsername = backStackEntry.arguments?.getString("username") ?: ""
                            val username = URLDecoder.decode(safeUsername, "UTF-8")
                            
                            val displayName = if (username.contains("@")) {
                                username.substringBefore("@").replaceFirstChar { it.uppercase() }
                            } else if (username.isNotEmpty()) {
                                username.replaceFirstChar { it.uppercase() }
                            } else {
                                "Admin"
                            }
                            
                            SetupScreen(
                                username = username,
                                onProceed = { dept, subj ->
                                    val safeDept = URLEncoder.encode(dept, "UTF-8")
                                    val safeSubj = URLEncoder.encode(subj, "UTF-8")
                                    val safeTeacher = URLEncoder.encode(displayName, "UTF-8")
                                    navController.navigate(Routes.createAttendanceRoute(safeDept, safeSubj, safeTeacher))
                                },
                                onGoToDashboard = { dept, subj ->
                                    val safeDept = URLEncoder.encode(dept, "UTF-8")
                                    val safeSubj = URLEncoder.encode(subj, "UTF-8")
                                    val safeTeacher = URLEncoder.encode(displayName, "UTF-8")
                                    navController.navigate(Routes.createDashboardRoute(safeDept, safeSubj, safeTeacher))
                                }
                            )
                        }
                        
                        composable(Routes.ATTENDANCE) { backStackEntry ->
                            val safeDept = backStackEntry.arguments?.getString("department") ?: ""
                            val safeSubj = backStackEntry.arguments?.getString("subject") ?: ""
                            val safeTeacher = backStackEntry.arguments?.getString("teacher") ?: ""
                            val dept = URLDecoder.decode(safeDept, "UTF-8")
                            val subj = URLDecoder.decode(safeSubj, "UTF-8")
                            val teacher = URLDecoder.decode(safeTeacher, "UTF-8")
                            
                            AttendanceScreen(
                                department = dept,
                                subject = subj,
                                onNavigateToDashboard = {
                                    navController.navigate(Routes.createDashboardRoute(safeDept, safeSubj, safeTeacher)) {
                                        popUpTo(Routes.ATTENDANCE) { inclusive = true }
                                    }
                                }
                            )
                        }
                        
                        composable(Routes.DASHBOARD) { backStackEntry ->
                            val safeDept = backStackEntry.arguments?.getString("department") ?: ""
                            val safeSubj = backStackEntry.arguments?.getString("subject") ?: ""
                            val safeTeacher = backStackEntry.arguments?.getString("teacher") ?: ""
                            val dept = URLDecoder.decode(safeDept, "UTF-8")
                            val subj = URLDecoder.decode(safeSubj, "UTF-8")
                            val teacher = URLDecoder.decode(safeTeacher, "UTF-8")
                            
                            DashboardScreen(
                                department = dept,
                                subject = subj,
                                teacherName = teacher
                            )
                        }
                    }
                }
            }
        }
    }
}
