package com.example.storage

import android.content.Context
import com.example.models.AttendanceSession
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

class AttendanceStorage(private val context: Context) {
    private val fileName = "attendance_master.json"
    
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
        
    private val listType = Types.newParameterizedType(List::class.java, AttendanceSession::class.java)
    private val adapter = moshi.adapter<List<AttendanceSession>>(listType)

    suspend fun saveSession(session: AttendanceSession) {
        withContext(Dispatchers.IO) {
            val sessions = getSessions().toMutableList()
            sessions.add(session)
            
            val file = File(context.filesDir, fileName)
            val json = adapter.toJson(sessions)
            file.writeText(json)
        }
    }

    suspend fun getSessions(): List<AttendanceSession> {
        return withContext(Dispatchers.IO) {
            val file = File(context.filesDir, fileName)
            if (!file.exists()) {
                return@withContext emptyList()
            }
            try {
                val json = file.readText()
                adapter.fromJson(json) ?: emptyList()
            } catch (e: IOException) {
                emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
