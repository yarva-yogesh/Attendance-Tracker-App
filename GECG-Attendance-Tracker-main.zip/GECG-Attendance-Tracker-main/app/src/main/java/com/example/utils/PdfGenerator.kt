package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.models.Student
import com.example.models.departmentStudents
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.models.AttendanceSession

object PdfGenerator {
    private val darkBlue = Color.parseColor("#124076")
    private val presentGreen = Color.parseColor("#15803d")
    private val absentRed = Color.parseColor("#b91c1c")
    private val lightGrey = Color.parseColor("#d1d5db")

    private fun drawHeaderAndLine(canvas: Canvas, paint: Paint, title: String) {
        paint.color = darkBlue
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText(title, 50f, 50f, paint)

        paint.color = darkBlue
        paint.strokeWidth = 2f
        canvas.drawLine(50f, 70f, 545f, 70f, paint)
    }

    private fun drawHorizontalLine(canvas: Canvas, paint: Paint, y: Float) {
        paint.color = lightGrey
        paint.strokeWidth = 1f
        canvas.drawLine(50f, y, 545f, y, paint)
    }

    fun generateAnalyticsPdf(
        context: Context,
        department: String,
        subject: String,
        sessions: List<AttendanceSession>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        val paint = Paint()
        
        drawHeaderAndLine(canvas, paint, "ATTENDANCE ANALYTICS SUMMARY")
        
        paint.color = darkBlue
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 14f
        var yPos = 100f
        canvas.drawText("Session Details:", 50f, yPos, paint)
        
        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 12f
        yPos += 20f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Subject Name & Code:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(subject, 200f, yPos, paint)
        
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Department:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(department, 200f, yPos, paint)

        val totalClasses = sessions.size
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Total Classes Held:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("$totalClasses", 200f, yPos, paint)
        
        yPos += 30f
        drawHorizontalLine(canvas, paint, yPos)
        yPos += 30f
        
        paint.color = darkBlue
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 12f
        canvas.drawText("USN / Roll", 50f, yPos, paint)
        canvas.drawText("Student Name", 180f, yPos, paint)
        canvas.drawText("Attendance", 450f, yPos, paint)
        
        yPos += 15f
        drawHorizontalLine(canvas, paint, yPos)
        yPos += 20f
        
        val students = departmentStudents[department] ?: emptyList()
        students.forEach { student ->
            if (yPos > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                yPos = 50f
                paint.color = Color.BLACK
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                drawHeaderAndLine(canvas, paint, "ANALYTICS SUMMARY (Cont.) - $subject")
                yPos = 100f
                paint.textSize = 12f
            }
            
            val attendedCount = sessions.count { session -> session.records[student.usn] == true }
            val percentage = if (totalClasses == 0) 0f else (attendedCount.toFloat() / totalClasses) * 100
            
            paint.color = Color.BLACK
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText(student.usn, 50f, yPos, paint)
            canvas.drawText(student.name, 180f, yPos, paint)
            
            if (percentage >= 75f) {
                paint.color = presentGreen
            } else {
                paint.color = absentRed
            }
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("$attendedCount / $totalClasses (${percentage.toInt()}%)", 450f, yPos, paint)
            
            yPos += 20f
        }
        
        document.finishPage(page)
        
        try {
            val pdfDir = File(context.cacheDir, "pdfs")
            if (!pdfDir.exists()) {
                pdfDir.mkdirs()
            }
            
            val subjectCode = subject.split(" ").firstOrNull() ?: "SUB"
            val dateFormat = SimpleDateFormat("dd|MM|yyyy", Locale.getDefault())
            val formattedDate = dateFormat.format(Date())
            
            val fileName = "$subjectCode-$formattedDate-analytics.pdf"
            val file = File(pdfDir, fileName)
            document.writeTo(FileOutputStream(file))
            document.close()
            
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Analytics PDF"))
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun generateAndSharePdf(
        context: Context,
        department: String,
        subject: String,
        date: String,
        presentStudents: List<Student>,
        absentStudents: List<Student>,
        teacherName: String
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size
        var page = document.startPage(pageInfo)
        var canvas: Canvas = page.canvas

        val paint = Paint()
        
        drawHeaderAndLine(canvas, paint, "ATTENDANCE SESSION SUMMARY")
        
        paint.color = darkBlue
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 14f
        var yPos = 100f
        canvas.drawText("Session Details:", 50f, yPos, paint)
        
        paint.color = Color.BLACK
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 12f
        yPos += 20f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Subject Name & Code:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(subject, 200f, yPos, paint)
        
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Teacher Name:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(teacherName, 200f, yPos, paint)
        
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Date:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(date, 200f, yPos, paint)
        
        val totalStrength = presentStudents.size + absentStudents.size
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Total Strength:", 50f, yPos, paint)
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("$totalStrength students", 200f, yPos, paint)
        
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Students Present:", 50f, yPos, paint)
        paint.color = presentGreen
        canvas.drawText("${presentStudents.size}", 200f, yPos, paint)
        
        paint.color = Color.BLACK
        yPos += 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Students Absent:", 50f, yPos, paint)
        paint.color = absentRed
        canvas.drawText("${absentStudents.size}", 200f, yPos, paint)
        
        yPos += 30f
        drawHorizontalLine(canvas, paint, yPos)
        yPos += 30f
        
        paint.color = presentGreen
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 12f
        canvas.drawText("Present Students (${presentStudents.size}):", 50f, yPos, paint)
        
        yPos += 20f
        paint.color = Color.BLACK
        canvas.drawText("USN / Roll", 50f, yPos, paint)
        canvas.drawText("Student Name", 180f, yPos, paint)
        canvas.drawText("Status", 450f, yPos, paint)
        
        yPos += 15f
        drawHorizontalLine(canvas, paint, yPos)
        yPos += 20f
        
        presentStudents.forEach { student ->
            if (yPos > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                paint.color = Color.BLACK
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                yPos = 50f
                drawHeaderAndLine(canvas, paint, "ATTENDANCE SUMMARY (Cont.) - $subject")
                yPos = 100f
                paint.textSize = 12f
            }
            
            paint.color = Color.BLACK
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText(student.usn, 50f, yPos, paint)
            canvas.drawText(student.name, 180f, yPos, paint)
            
            paint.color = presentGreen
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("Present", 450f, yPos, paint)
            
            yPos += 20f
        }
        
        yPos += 20f
        if (yPos > 700f) { // Leave space for absent header
            document.finishPage(page)
            page = document.startPage(pageInfo)
            canvas = page.canvas
            paint.color = Color.BLACK
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            yPos = 50f
            drawHeaderAndLine(canvas, paint, "ATTENDANCE SUMMARY (Cont.) - $subject")
            yPos = 100f
            paint.textSize = 12f
        }
        
        paint.color = absentRed
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Absent Students (${absentStudents.size}):", 50f, yPos, paint)
        yPos += 20f
        
        if (absentStudents.isEmpty()) {
            paint.color = Color.BLACK
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("No students absent.", 65f, yPos, paint)
        } else {
            paint.color = Color.BLACK
            canvas.drawText("USN / Roll", 50f, yPos, paint)
            canvas.drawText("Student Name", 180f, yPos, paint)
            canvas.drawText("Status", 450f, yPos, paint)
            
            yPos += 15f
            drawHorizontalLine(canvas, paint, yPos)
            yPos += 20f
            
            absentStudents.forEach { student ->
                if (yPos > 780f) {
                    document.finishPage(page)
                    page = document.startPage(pageInfo)
                    canvas = page.canvas
                    paint.color = Color.BLACK
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    yPos = 50f
                    drawHeaderAndLine(canvas, paint, "ATTENDANCE SUMMARY (Cont.) - $subject")
                    yPos = 100f
                    paint.textSize = 12f
                }
                
                paint.color = Color.BLACK
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                canvas.drawText(student.usn, 50f, yPos, paint)
                canvas.drawText(student.name, 180f, yPos, paint)
                
                paint.color = absentRed
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("Absent", 450f, yPos, paint)
                
                yPos += 20f
            }
        }
        
        document.finishPage(page)
        
        try {
            val pdfDir = File(context.cacheDir, "pdfs")
            if (!pdfDir.exists()) {
                pdfDir.mkdirs()
            }
            // Parse subject code for title
            val subjectCode = subject.split(" ").firstOrNull() ?: "SUB"
            // Format date as DD|MM|YYYY
            val formattedDate = date.replace("-", "|").let {
                val parts = it.split("|")
                if (parts.size == 3) {
                    val day = if (parts[0].length == 4) parts[2] else parts[0]
                    val month = parts[1]
                    val year = if (parts[0].length == 4) parts[0] else parts[2]
                    "$day|$month|$year"
                } else {
                    it
                }
            }
            
            val fileName = "$subjectCode-$formattedDate-report.pdf"
            val file = File(pdfDir, fileName)
            document.writeTo(FileOutputStream(file))
            document.close()
            
            // Share
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share PDF Report"))
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
