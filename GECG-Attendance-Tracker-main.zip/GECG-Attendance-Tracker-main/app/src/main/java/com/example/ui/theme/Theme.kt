package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val AppColorScheme =
  darkColorScheme(
    primary = SkyBlueAccent,
    onPrimary = CharcoalBackground,
    secondary = LightBlueAccent,
    onSecondary = CharcoalBackground,
    tertiary = DeepNavy,
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    error = WarningColor,
    onError = CharcoalBackground
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme as requested
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false, // Disable dynamic color to enforce branding
  content: @Composable () -> Unit,
) {
  val colorScheme = AppColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
