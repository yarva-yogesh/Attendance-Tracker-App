package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CharcoalBackground = Color(0xFF0A0E17)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceCard = Color(0xFF161B2C)
val SurfaceCardLight = Color(0xFF1E293B)
val DeepNavy = Color(0xFF1E40AF)
val SkyBlueAccent = Color(0xFF0EA5E9)
val LightBlueAccent = Color(0xFF7DD3FC)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val WarningColor = Color(0xFFF59E0B)

