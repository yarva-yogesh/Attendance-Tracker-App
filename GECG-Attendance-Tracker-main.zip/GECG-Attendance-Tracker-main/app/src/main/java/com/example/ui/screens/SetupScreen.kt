package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    username: String,
    onProceed: (department: String, subject: String) -> Unit,
    onGoToDashboard: (department: String, subject: String) -> Unit = {_, _ ->}
) {
    val departments = listOf(
        "Computer Science & Engg",
        "Electronic & Communication Engg",
        "Mechanical Engg",
        "Civil Engg",
        "Electrical & Electronic Engg"
    )
    
    val subjects = listOf(
        "BCS701 - Internet of Things",
        "BCS702 - Parallel Computing",
        "BCS703 - Cryptography & Network Security"
    )

    var expandedDept by remember { mutableStateOf(false) }
    var selectedDept by remember { mutableStateOf("") }
    
    var expandedSubj by remember { mutableStateOf(false) }
    var selectedSubj by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GEC - Gangavathi", style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
        ) {
            val displayName = if (username.contains("@")) {
                username.substringBefore("@").replaceFirstChar { it.uppercase() }
            } else if (username.isNotEmpty()) {
                username.replaceFirstChar { it.uppercase() }
            } else {
                ""
            }
            
            val titleText = if (displayName.isNotEmpty()) "Hello $displayName - Welcome" else "Institutional Setup"
            
            Text(
                text = titleText,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            ExposedDropdownMenuBox(
                expanded = expandedDept,
                onExpandedChange = { expandedDept = it }
            ) {
                OutlinedTextField(
                    value = selectedDept,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Department") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDept) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                )
                
                ExposedDropdownMenu(
                    expanded = expandedDept,
                    onDismissRequest = { expandedDept = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    departments.forEach { dept ->
                        DropdownMenuItem(
                            text = { Text(dept) },
                            onClick = {
                                selectedDept = dept
                                expandedDept = false
                            }
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            ExposedDropdownMenuBox(
                expanded = expandedSubj,
                onExpandedChange = { expandedSubj = it }
            ) {
                OutlinedTextField(
                    value = selectedSubj,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select Academic Subject") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSubj) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                )
                
                ExposedDropdownMenu(
                    expanded = expandedSubj,
                    onDismissRequest = { expandedSubj = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    subjects.forEach { subj ->
                        DropdownMenuItem(
                            text = { Text(subj) },
                            onClick = {
                                selectedSubj = subj
                                expandedSubj = false
                            }
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            Button(
                onClick = { onGoToDashboard(selectedDept, selectedSubj) },
                enabled = selectedDept.isNotEmpty() && selectedSubj.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text("Direct to Analytics Dashboard", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = androidx.compose.ui.unit.TextUnit(16f, androidx.compose.ui.unit.TextUnitType.Sp))
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = { onProceed(selectedDept, selectedSubj) },
                enabled = selectedDept.isNotEmpty() && selectedSubj.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Continue to Attendance", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = androidx.compose.ui.unit.TextUnit(16f, androidx.compose.ui.unit.TextUnitType.Sp))
            }
        }
    }
}
