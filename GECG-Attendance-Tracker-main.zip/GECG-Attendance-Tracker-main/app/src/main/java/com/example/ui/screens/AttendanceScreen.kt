package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.AttendanceSession
import com.example.models.departmentStudents
import com.example.storage.AttendanceStorage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    department: String,
    subject: String,
    onNavigateToDashboard: () -> Unit
) {
    val context = LocalContext.current
    val storage = remember { AttendanceStorage(context) }
    val coroutineScope = rememberCoroutineScope()
    
    val students = departmentStudents[department] ?: emptyList()
    // Map of USN to presence state, default to false (absent)
    val attendanceState = remember { mutableStateMapOf<String, Boolean>().apply {
        students.forEach { put(it.usn, false) }
    } }
    
    val presentCount = attendanceState.values.count { it }
    val absentCount = attendanceState.size - presentCount
    
    var showSummaryDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text(department, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, letterSpacing = 2.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                PaddingValues(16.dp)
                Button(
                    onClick = { showSummaryDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Review Session Summary")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Live Counter Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CounterBox("Present", presentCount, MaterialTheme.colorScheme.primary)
                CounterBox("Absent", absentCount, MaterialTheme.colorScheme.error)
            }
            
            // Student List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(students) { student ->
                    val isPresent = attendanceState[student.usn] ?: false
                    StudentCard(
                        name = student.name,
                        usn = student.usn,
                        isPresent = isPresent,
                        onToggle = { attendanceState[student.usn] = !isPresent }
                    )
                }
            }
        }
    }
    
    if (showSummaryDialog) {
        AlertDialog(
            onDismissRequest = { showSummaryDialog = false },
            title = { Text("Session Summary") },
            text = {
                Column {
                    Text("Total Strength: ${students.size}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Present: $presentCount", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Absent: $absentCount", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val session = AttendanceSession(
                            id = System.currentTimeMillis(),
                            date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date()),
                            department = department,
                            subject = subject,
                            records = attendanceState.toMap()
                        )
                        coroutineScope.launch {
                            storage.saveSession(session)
                            Toast.makeText(context, "Attendance Saved", Toast.LENGTH_SHORT).show()
                            showSummaryDialog = false
                            onNavigateToDashboard()
                        }
                    }
                ) {
                    Text("Confirm & Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSummaryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CounterBox(label: String, count: Int, color: androidx.compose.ui.graphics.Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(vertical = 12.dp, horizontal = 24.dp)
    ) {
        Text(count.toString(), style = MaterialTheme.typography.headlineMedium, color = color, fontWeight = FontWeight.Bold)
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun StudentCard(
    name: String,
    usn: String,
    isPresent: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(
            containerColor = if (isPresent) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(usn, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Checkbox(
                checked = isPresent,
                onCheckedChange = null,
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            )
        }
    }
}
