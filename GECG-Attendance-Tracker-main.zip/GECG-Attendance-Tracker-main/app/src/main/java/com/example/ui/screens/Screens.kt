package com.example.ui.screens

object Routes {
    const val LOGIN = "login"
    const val SETUP = "setup/{username}"
    const val ATTENDANCE = "attendance/{department}/{subject}/{teacher}"
    const val DASHBOARD = "dashboard/{department}/{subject}/{teacher}"
    
    fun createSetupRoute(username: String): String {
        return "setup/$username"
    }
    
    fun createAttendanceRoute(department: String, subject: String, teacher: String): String {
        return "attendance/$department/$subject/$teacher"
    }
    
    fun createDashboardRoute(department: String, subject: String, teacher: String): String {
        return "dashboard/$department/$subject/$teacher"
    }
}
