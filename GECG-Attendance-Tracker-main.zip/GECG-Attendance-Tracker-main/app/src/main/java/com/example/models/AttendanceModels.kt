package com.example.models

data class AttendanceSession(
    val id: Long,
    val date: String,
    val department: String,
    val subject: String,
    val records: Map<String, Boolean>
)

data class Student(
    val usn: String,
    val name: String
)

val departmentStudents = mapOf(
    "Computer Science & Engg" to listOf(
        Student("3NG23CS002", "ABHISHEK"),
        Student("3NG23CS003", "ABHISHEK GOUDA"),
        Student("3NG23CS004", "AISHWARYA G"),
        Student("3NG23CS005", "AMARESH"),
        Student("3NG23CS006", "ANUSHA G"),
        Student("3NG23CS007", "ASFIYA JALEES"),
        Student("3NG23CS009", "ASMA IMAMASAB"),
        Student("3NG23CS010", "B AKHILA"),
        Student("3NG23CS012", "BASAVARAJ M A"),
        Student("3NG23CS014", "BINDUSHREE S"),
        Student("3NG23CS015", "DARSHAN BIDARAHALLI"),
        Student("3NG23CS017", "DEVIKA"),
        Student("3NG23CS020", "IRAMMA ANGADI"),
        Student("3NG23CS022", "K MAHESH KUMAR"),
        Student("3NG23CS024", "KARTHIK G V"),
        Student("3NG23CS025", "KAVITA ALLAPUR"),
        Student("3NG23CS026", "KOUSALYA B K"),
        Student("3NG23CS027", "KOUSHAL RATHOD"),
        Student("3NG23CS028", "LAXMI"),
        Student("3NG23CS029", "M AKASH"),
        Student("3NG23CS030", "M BHARGAVI"),
        Student("3NG23CS031", "MALLAMMA"),
        Student("3NG23CS032", "NAGALAPURADA HANUMESHA"),
        Student("3NG23CS033", "NAGARAJ BENNUR"),
        Student("3NG23CS035", "NAVEENAGOUDA"),
        Student("3NG23CS036", "NETRAVATHI"),
        Student("3NG23CS037", "NIVEDITA"),
        Student("3NG23CS038", "P PRIYANKA"),
        Student("3NG23CS040", "PRAGATI HONGAL"),
        Student("3NG23CS041", "RAGHUNANDA B"),
        Student("3NG23CS042", "RAGI JAGANNATHAIAH"),
        Student("3NG23CS043", "RAHUL"),
        Student("3NG23CS044", "RAJUGOUDA"),
        Student("3NG23CS045", "RAKSHITHA DAROJI"),
        Student("3NG23CS046", "REVANASIDDAYYA"),
        Student("3NG23CS047", "RUKSANA BEGUM P"),
        Student("3NG23CS048", "S M LAVANYA"),
        Student("3NG23CS049", "SABA SULTANA"),
        Student("3NG23CS050", "SAMEENA"),
        Student("3NG23CS051", "SHARADA GALABI"),
        Student("3NG23CS052", "SINDHU"),
        Student("3NG23CS053", "SUNIL"),
        Student("3NG23CS054", "TEJASHWINI VAJRAD"),
        Student("3NG23CS055", "TUKARAMAPPA"),
        Student("3NG23CS056", "VINOD"),
        Student("3NG23CS057", "YUVARAJ B H"),
        Student("3NG23CS058", "RANJITHA K"),
        Student("3NG24CS400", "AISHWARYA LALGE"),
        Student("3NG24CS401", "HOMBANNANAVARA SHIVARAJA"),
        Student("3NG24CS402", "IQHRA FATHIMA D A"),
        Student("3NG24CS403", "KAMALA"),
        Student("3NG24CS404", "MD RAFEEQ MANIYAR"),
        Student("3NG24CS405", "MOHAMMED SAFIUDDIN"),
        Student("3NG24CS406", "Y S YOGESH")
    ).sortedBy { it.usn }, // Ensure it's sorted by USN as requested
    "Electronic & Communication Engg" to listOf(
        Student("EC001", "Fiona Gallagher"),
        Student("EC002", "George Miller"),
        Student("EC003", "Hannah Abbott"),
        Student("EC004", "Ian Somerhalder"),
        Student("EC005", "Jenna Ortega")
    ),
    "Mechanical Engg" to listOf(
        Student("ME001", "Harry Potter"),
        Student("ME002", "Ian Malcolm"),
        Student("ME003", "John Doe"),
        Student("ME004", "Jane Smith"),
        Student("ME005", "Jack Reacher"),
        Student("ME006", "Tony Stark")
    ),
    "Civil Engg" to listOf(
        Student("CE001", "Jack Sparrow"),
        Student("CE002", "Kevin Flynn"),
        Student("CE003", "Laura Croft"),
        Student("CE004", "Michael Scott"),
        Student("CE005", "Nathan Drake"),
        Student("CE006", "Oscar Isaac"),
        Student("CE007", "Peter Parker")
    ),
    "Electrical & Electronic Engg" to listOf(
        Student("EE001", "Luke Skywalker"),
        Student("EE002", "Marty McFly"),
        Student("EE003", "Neil Armstrong"),
        Student("EE004", "Owen Wilson")
    )
)
