import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun main() {
    val dateFormat = SimpleDateFormat("dd|MM|yy", Locale.getDefault())
    val formattedDate = dateFormat.format(Date())
    println("fileName = SUB-$formattedDate-analytics.pdf")
}
